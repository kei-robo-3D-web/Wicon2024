﻿using UnityEngine;
using UnityEngine.UI;

public class iBeaconItemScript : MonoBehaviour
{
	public Text TextUUID;
	public Text TextRSSIValue;
	public Text TextAndroidSignalPower;
	public Text TextDistance;
	public Text TextiOSProximity;
}
