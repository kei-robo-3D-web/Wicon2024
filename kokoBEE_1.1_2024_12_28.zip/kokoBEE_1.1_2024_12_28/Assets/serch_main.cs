using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Android;

public class serch_main : MonoBehaviour
{
    private float _timeout;
    private float _startScanTimeout = 10.0f;
    private float _startScanDelay   = 0.5f;
    private float radReader = 0.0f;
    private int[] _scanBeaconCount  = new int[4];
    private bool  _startScan        = true;
    private bool _scanFlag = false;
    private int nowAreaX = 0;
    private int nowAreaY = 0;
    
    private const float dataRange   = 50;

    Text nowArea;
    public  GameObject nowAreaObject;
    
    Text[] rssiText = new Text[4];
    public GameObject[] rssiTextObject = new GameObject[4];

    Text scan;
    public GameObject scanObject;

    Text radText;
    public GameObject radTextObject;
    
    // Start is called before the first frame update
    void Start()
    {
        BLE_data.areaSize = BLE_data.areaSizeX * BLE_data.areaSizeY;
        BLE_data.RSSI_base = new double[BLE_data.areaSizeX, BLE_data.areaSizeY, 4];
        BLE_data.sigmaY2 = new double[BLE_data.areaSize];

        nowArea = nowAreaObject .GetComponent<Text>();
        scan    = scanObject    .GetComponent<Text>();
        radText = radTextObject .GetComponent<Text>();

        for (int i = 0; i < 4; i++) {
            rssiText[i] = rssiTextObject[i].GetComponent<Text>();
        }

        Input.gyro.enabled = true;//�W���C���Z���T�̏�����

        nowArea.text = BLE_data.nowAreaCount.ToString();
        BluetoothLEHardwareInterface.Initialize(true, false, () => {

            _timeout = _startScanDelay;
        },
      (error) => {

          BluetoothLEHardwareInterface.Log("Error: " + error);

          if (error.Contains("Bluetooth LE Not Enabled"))
              BluetoothLEHardwareInterface.BluetoothEnable(true);
      });
    }

    // Update is called once per frame
    void Update()
    {
        nowAreaX = BLE_data.nowAreaCount % BLE_data.areaSizeX;
        nowAreaY = BLE_data.nowAreaCount / BLE_data.areaSizeX;

        if (_timeout > 0f)
        {
            _timeout -= Time.deltaTime;
            if (_timeout <= 0f)
            {
                if (_startScan)
                {
                    _startScan = false;
                    _timeout = _startScanTimeout;

                    BluetoothLEHardwareInterface.ScanForPeripheralsWithServices(null, null, (address, name, rssi, bytes) =>
                    {

                        if (name == "1" && _scanBeaconCount[0] < dataRange)
                        {
                            _scanBeaconCount[0]++;
                            BLE_data.RSSI1_sum += rssi;
                        }
                        else if (name == "2" && _scanBeaconCount[1] < dataRange)
                        {
                            _scanBeaconCount[1]++;
                            BLE_data.RSSI2_sum += rssi;
                        }
                        else if (name == "3" && _scanBeaconCount[2] < dataRange)
                        {
                            _scanBeaconCount[2]++;
                            BLE_data.RSSI3_sum += rssi;
                        }
                        else if (name == "4" && _scanBeaconCount[3] < dataRange)
                        {
                            _scanBeaconCount[3]++;
                            BLE_data.RSSI4_sum += rssi;
                        }

                    }, true);
                }
                else
                {
                    BluetoothLEHardwareInterface.StopScan();
                    _startScan = true;
                    _timeout = _startScanDelay;
                }
            }
        }

        Quaternion gattitude = Input.gyro.attitude;//�p�x���擾(�k�������ĉ�ʂ���ɂ��Ēu������Ԃ����Z-up��-1.0�`1.0)
        radReader = (gattitude.z + 1.0f) * 180;
        radText.text = radReader.ToString();

        if (_scanFlag)
        {
            scan.text = "Scan Compleat";
        }
        else {
            scan.text = "Scaninng...";
        }
        /*RSSI�̕��ϒl���Z�o*/
        if (_scanBeaconCount[0] >= dataRange &&
            _scanBeaconCount[1] >= dataRange &&
            _scanBeaconCount[2] >= dataRange &&
            _scanBeaconCount[3] >= dataRange)
        {
            BLE_data.RSSI_base[nowAreaX, nowAreaY, 0] = (double)BLE_data.RSSI1_sum / (double)dataRange;
            BLE_data.RSSI_base[nowAreaX, nowAreaY, 1] = (double)BLE_data.RSSI2_sum / (double)dataRange;
            BLE_data.RSSI_base[nowAreaX, nowAreaY, 2] = (double)BLE_data.RSSI3_sum / (double)dataRange;
            BLE_data.RSSI_base[nowAreaX, nowAreaY, 3] = (double)BLE_data.RSSI4_sum / (double)dataRange;

            BLE_data.sigmaY2[BLE_data.nowAreaCount] = BLE_data.RSSI_base[nowAreaX, nowAreaY, 0] * BLE_data.RSSI_base[nowAreaX, nowAreaY, 0] +
                                                      BLE_data.RSSI_base[nowAreaX, nowAreaY, 1] * BLE_data.RSSI_base[nowAreaX, nowAreaY, 1] +
                                                      BLE_data.RSSI_base[nowAreaX, nowAreaY, 2] * BLE_data.RSSI_base[nowAreaX, nowAreaY, 2] +
                                                      BLE_data.RSSI_base[nowAreaX, nowAreaY, 3] * BLE_data.RSSI_base[nowAreaX, nowAreaY, 3] ;
            for (int i = 0; i < 4; i++) {
                rssiText[i].text = BLE_data.RSSI_base[nowAreaX, nowAreaY, i].ToString();
            }
            _scanFlag = true;
        }
    }

    public void OnStopScanning()
    {
        BluetoothLEHardwareInterface.Log("**************** stopping");
        BluetoothLEHardwareInterface.StopScan();
    }

    public void OnCountButton() {
        BLE_data.nowAreaCount++;
        if (BLE_data.nowAreaCount >= BLE_data.areaSize)
        {
            BLE_data.nowAreaCount = 0;
        }
        nowArea.text = BLE_data.nowAreaCount.ToString();
        _scanBeaconCount[0] = 0;
        _scanBeaconCount[1] = 0;
        _scanBeaconCount[2] = 0;
        _scanBeaconCount[3] = 0;
        BLE_data.RSSI1_sum = 0;
        BLE_data.RSSI2_sum = 0;
        BLE_data.RSSI3_sum = 0;
        BLE_data.RSSI4_sum = 0;
        _scanFlag = false;

        for (int i = 0; i < 4; i++)
        {
            rssiText[i].text = "0";
        }
    }

    public void changeScene() {
        SceneManager.LoadScene("main");
    }
}
