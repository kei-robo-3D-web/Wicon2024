using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class BLE_scan : MonoBehaviour
{
    private float _timeout;
    private float _startScanTimeout = 10f;
    private float _startScanDelay = 0.5f;
    private bool _startScan = true;
    private double[] simirality;
    private double[] euclideanDistance;
    private int _simiralityFlag = 0;
    double _simiralityMax = 0;
    double _euclianMin = 100;
    int _simiralityNowX = 0;
    int _simiralityNowY = 0;
    int _euclianNowX = 0;
    int _euclianNowY = 0;

    Text euclianText;
    public GameObject euclianTextObject;

    private string _targetDeviceAddress = ""; // �ڑ��Ώۂ̃f�o�C�X�A�h���X
    private bool _isConnecting = false;

    // Start is called before the first frame update
    void Start()
    {
        BLE_data.areaSize = BLE_data.areaSizeX * BLE_data.areaSizeY;
        euclianText = euclianTextObject.GetComponent<Text>();
        simirality = new double[BLE_data.areaSize];
        euclideanDistance = new double[BLE_data.areaSize];
        BluetoothLEHardwareInterface.Initialize(true, false, () => {
            _timeout = _startScanDelay;
        },
        (error) => {
            BluetoothLEHardwareInterface.Log("Error: " + error);
            if (error.Contains("Bluetooth LE Not Enabled"))
                BluetoothLEHardwareInterface.BluetoothEnable(true);
        });
    }

    // Update is called once per frame
    void Update()
    {
        if (_timeout > 0f)
        {
            _timeout -= Time.deltaTime;
            if (_timeout <= 0f)
            {
                if (_startScan && !_isConnecting)
                {
                    _startScan = false;
                    _timeout = _startScanTimeout;

                    BluetoothLEHardwareInterface.ScanForPeripheralsWithServices(null, null, (address, name, rssi, bytes) =>
                    {
                        //Debug.Log($"Device Found: {name} ({address}) RSSI: {rssi}");

                        // �����ɍ����f�o�C�X�𔭌�������ڑ������݂�
                        if (name == BLE_data.connectionName) // �C�ӂ̖��O���w��
                        {
                            _targetDeviceAddress = address;
                            ConnectToDevice(_targetDeviceAddress);
                        }

                        // RSSI�̏���
                        if (name == "1")
                        {
                            BLE_data.RSSI_measure[0] = rssi;
                        }
                        else if (name == "2")
                        {
                            BLE_data.RSSI_measure[1] = rssi;
                        }
                        else if (name == "3")
                        {
                            BLE_data.RSSI_measure[2] = rssi;
                        }
                        else if (name == "4")
                        {
                            BLE_data.RSSI_measure[3] = rssi;
                        }
                    }, true);
                }
                else
                {
                    BluetoothLEHardwareInterface.StopScan();
                    _startScan = true;
                    _timeout = _startScanDelay;
                }
            }
        }

        if (_simiralityFlag == 0)
        {
            _simiralityFlag = 1;
            for (int i = 0; i < BLE_data.areaSize; i++)
            {
                Similarity(i);
                EuclideanDistance(i);
            }

            for (int i = 0; i < BLE_data.areaSize; i++)
            {
                if (simirality[i] > _simiralityMax)
                {
                    _simiralityMax = simirality[i];
                    _simiralityNowX = i % BLE_data.areaSizeX;
                    _simiralityNowY = i / BLE_data.areaSizeX;
                }

                if (euclideanDistance[i] < _euclianMin)
                {
                    _euclianMin = euclideanDistance[i];
                    _euclianNowX = i % BLE_data.areaSizeX;
                    _euclianNowY = i / BLE_data.areaSizeX;
                }
            }

            _simiralityMax = 0;
            _euclianMin = 100;
            euclianText.text = _euclianNowX.ToString() + "," + _euclianNowY.ToString();
            BLE_data.areaNowX = _euclianNowX;
            BLE_data.areaNowY = _euclianNowY;
            _simiralityFlag = 0;
        }

        for (int i = 0; i < 4; i++)
        {
            Debug.Log(BLE_data.RSSI_base[0, 0, i]);
        }
    }

    void ConnectToDevice(string address)
    {
        if (_isConnecting) return;
        _isConnecting = true;

        BluetoothLEHardwareInterface.ConnectToPeripheral(address, null, null, (deviceAddress, serviceUUID, characteristicUUID) =>
        {
            Debug.Log($"Connected to {deviceAddress} Service: {serviceUUID} Characteristic: {characteristicUUID}");

            // �f�[�^���擾����L�����N�^���X�e�B�b�NUUID���m�F
            if (serviceUUID == "6e400001-b5a3-f393-e0a9-e50e24dcca9e" && characteristicUUID == "6e400003-b5a3-f393-e0a9-e50e24dcca9e")
            {
                // �L�����N�^���X�e�B�b�N�̃f�[�^���w��
                SubscribeToCharacteristic(deviceAddress, serviceUUID, characteristicUUID);
            }

            _isConnecting = false;
        }, (disconnectedAddress) =>
        {
            Debug.Log($"Disconnected from {disconnectedAddress}");
            _isConnecting = false;
        });
    }

    void SubscribeToCharacteristic(string deviceAddress, string serviceUUID, string characteristicUUID)
    {
        BluetoothLEHardwareInterface.SubscribeCharacteristicWithDeviceAddress(
            deviceAddress,
            serviceUUID,
            characteristicUUID,
            null, // �f�[�^���ύX���ꂽ�ۂ̃R�[���o�b�N
            (address, characteristic, data) =>
            {
                // ��M�f�[�^������
                BLE_data.targetArea = (BitConverter.ToInt32(data));
                string receivedData = BLE_data.targetArea.ToString();
                Debug.Log($"Data Received: {receivedData} from {characteristic}");
            }
        );
    }


    void Similarity(int area)
    {
        double sigmaX2 = 0;
        double sigmaXY = 0;
        int areaY = area / BLE_data.areaSizeX;
        int areaX = area % BLE_data.areaSizeX;

        for (int i = 0; i < 4; i++)
        {
            sigmaX2 += BLE_data.RSSI_measure[i] * BLE_data.RSSI_measure[i];
        }

        for (int i = 0; i < 4; i++)
        {
            sigmaXY += BLE_data.RSSI_measure[i] * BLE_data.RSSI_base[areaX, areaY, i];
        }

        simirality[area] = sigmaXY / (Math.Sqrt(sigmaX2) * Math.Sqrt(BLE_data.sigmaY2[area]));
        BluetoothLEHardwareInterface.Log(area.ToString() + ":" + simirality[area].ToString());
    }

    void EuclideanDistance(int area)
    {
        double sum = 0.0;
        int areaY = area / BLE_data.areaSizeX;
        int areaX = area % BLE_data.areaSizeX;
        for (int i = 0; i < 4; i++)
        {
            sum += (BLE_data.RSSI_base[areaX, areaY, i] - BLE_data.RSSI_measure[i]) * (BLE_data.RSSI_base[areaX, areaY, i] - BLE_data.RSSI_measure[i]);
        }
        euclideanDistance[area] = Math.Sqrt(sum);
    }
}
