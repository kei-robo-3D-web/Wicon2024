using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;

public class main : MonoBehaviour
{
    string inputVoice;
    int inputState = 0;
    int vibFlag = 0;

    int[] nowPos = new int[2];
    int[] targetPos = new int[2];
    int[] distancePos = new int[2];

    const int X = 0;
    const int Y = 1;

    float nowRad = 0.0f;
    float targetRad = 0.0f;
    float betweenRad = 0.0f;
    float distance = 0.0f;

    string targetName;

    public AudioClip sound1; // �E�ł�
    public AudioClip sound2; // ���ł�
    public AudioClip sound3; // �܂������ł�
    public AudioClip sound4; // �߂��ɂ���܂���

    Text targetText;
    public GameObject targetTextObject;

    Text distanceText;
    public GameObject distanceTextObject;

    InputField connectionTarget;
    public GameObject connectionTargetObject;

    AudioSource audioSource;

    System.Timers.Timer voiceGide = new System.Timers.Timer(2000);
    // Start is called before the first frame update
    void Start()
    {
        targetText = targetTextObject.GetComponent<Text>();
        distanceText = distanceTextObject.GetComponent<Text>();
        connectionTarget = connectionTargetObject.GetComponent<InputField>();

        Input.gyro.enabled = true;//�W���C���Z���T�̏�����

        audioSource = GetComponent<AudioSource>();//�����o�͂̏�����

        voiceGide.Elapsed += (sender, e) =>
        {
            if (betweenRad >= 30)
            {
                PlaySoundByInput(1);
            }
            else
            if (betweenRad <= -30)
            {
                PlaySoundByInput(2);
            }
            else
            if (betweenRad > -30 && betweenRad < 30)
            {
                PlaySoundByInput(3);
            }
            else
            {
                PlaySoundByInput(4);
            }
        };

        voiceGide.Start();

        //targetPos[X] = 1;
        //targetPos[Y] = 2;
    }

    // Update is called once per frame
    void Update()
    {
        BLE_data.connectionName = connectionTarget.text;
        Quaternion gattitude = Input.gyro.attitude;//�p�x���擾(�k�������ĉ�ʂ���ɂ��Ēu������Ԃ����Z-up��-1.0�`1.0)
        nowRad = (gattitude.z + 1.0f) * 180;

        targetPos[X] = BLE_data.targetArea % BLE_data.areaSizeX;
        targetPos[Y] = BLE_data.targetArea / BLE_data.areaSizeX;

        distancePos[X] = targetPos[X] - nowPos[X];
        distancePos[Y] = targetPos[Y] - nowPos[Y];

        distance = Mathf.Sqrt((float)distancePos[X] * (float)distancePos[X] + (float)distancePos[Y] * (float)distancePos[Y]);
        targetRad = (float)Math.Atan2((double)distancePos[Y], (double)distancePos[X]) * 180.0f / 3.14f;

        targetText.text = targetPos[X].ToString() + "," + targetPos[Y].ToString();
        distanceText.text = distance.ToString();
        if (targetRad < 0)
        {
            targetRad = (180 - targetRad) + 180;
        }

        betweenRad = nowRad - targetRad;

        if (vibFlag == 0)
        {
            StartCoroutine(Vibrate());
        }
    }

    public void OnPrefarence() {
        SceneManager.LoadScene("RssiSearch");
    }


    public void PlaySoundByInput(int input)
    {
        if (!audioSource.isPlaying) // ���łɍĐ�����Ă��Ȃ��ꍇ�ɍĐ�
        {
            switch (input)
            {
                case 1:
                    audioSource.PlayOneShot(sound1);
                    break;
                case 2:
                    audioSource.PlayOneShot(sound2);
                    break;
                case 3:
                    audioSource.PlayOneShot(sound3);
                    break;
                case 4:
                    audioSource.PlayOneShot(sound4);
                    break;
            }
        }
    }

    IEnumerator Vibrate()
    {
        vibFlag = 1;
        Handheld.Vibrate();
        yield return new WaitForSeconds(0.5f * distance);
        vibFlag = 0;
    }
}
