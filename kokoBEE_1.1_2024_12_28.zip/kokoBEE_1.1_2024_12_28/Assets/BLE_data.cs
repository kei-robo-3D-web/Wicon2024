using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BLE_data
{
    public static double[,,] RSSI_base;
    public static int[]   RSSI_measure = new int[4];

    public static int areaSize = 0;
    public static int areaSizeX = 2;
    public static int areaSizeY = 4;
    public static int areaNowX = 0;
    public static int areaNowY = 0;

    public static double RSSI1_ave;
    public static double RSSI2_ave;
    public static double RSSI3_ave;
    public static double RSSI4_ave;

    public static int RSSI1_sum;
    public static int RSSI2_sum;
    public static int RSSI3_sum;
    public static int RSSI4_sum;

    public static string[] targetName = new string[10] { "�����R��","���z","","","","","","","","", };
    public static string connectionName = "";
    public static bool connnectFlag = false;
    public static string targetAddress = "";
    public static int targetArea;

    public static int nowAreaCount = 0;

    public static double[] sigmaY2;

}
